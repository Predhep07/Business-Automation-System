"""Business Operations Automation System - command line entry point.

Usage:
    python main.py demo        # create sample files and run the pipeline once
    python main.py run         # run the pipeline once (batch mode)
    python main.py schedule    # run repeatedly every N seconds
"""
import argparse
import json
import os
import sys

from automation.logger_setup import setup_logging
from automation.pipeline import run_pipeline
from automation.sample_data import create_sample_inbox
from automation.scheduler import run_scheduled


def load_config(path: str) -> dict:
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        sys.exit(f"Cannot read config '{path}': {exc}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Business Operations Automation System")
    parser.add_argument("command", choices=["demo", "run", "schedule"])
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--interval", type=int, help="seconds between runs (schedule)")
    parser.add_argument("--max-runs", type=int, help="stop after N runs (schedule)")
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(os.path.join(cfg["workspace"], "logs"), cfg.get("log_level", "INFO"))

    if args.command == "demo":
        create_sample_inbox(os.path.join(cfg["workspace"], "inbox"))
    if args.command in ("demo", "run"):
        result = run_pipeline(cfg)
        print("\nReports:", *result["reports"], sep="\n  ")
        return 0 if result["ok"] else 1
    interval = args.interval or cfg.get("schedule_interval_seconds", 3600)
    run_scheduled(lambda: run_pipeline(cfg), interval, args.max_runs)
    return 0


if __name__ == "__main__":
    sys.exit(main())
