"""Execution scheduling using only the standard library."""
import logging
import time

log = logging.getLogger("automation")


def run_scheduled(task, interval_seconds: int, max_runs: int = None) -> None:
    """Call task() every interval_seconds. Stop with Ctrl+C or after max_runs."""
    runs = 0
    log.info("Scheduler started: every %ss%s", interval_seconds,
             f", max {max_runs} runs" if max_runs else " (Ctrl+C to stop)")
    try:
        while max_runs is None or runs < max_runs:
            try:
                task()
            except Exception:
                log.exception("Scheduled run failed; will retry next interval")
            runs += 1
            if max_runs is not None and runs >= max_runs:
                break
            time.sleep(interval_seconds)
    except KeyboardInterrupt:
        log.info("Scheduler stopped by user")
