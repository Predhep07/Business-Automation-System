"""Central logging configuration (console + rotating log file)."""
import logging
import os
from logging.handlers import RotatingFileHandler

FORMAT = "%(asctime)s | %(levelname)-8s | %(module)s | %(message)s"


def setup_logging(log_dir: str, level: str = "INFO") -> logging.Logger:
    """Configure and return the shared 'automation' logger."""
    os.makedirs(log_dir, exist_ok=True)
    logger = logging.getLogger("automation")
    if logger.handlers:  # already configured
        return logger
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    formatter = logging.Formatter(FORMAT)

    file_handler = RotatingFileHandler(
        os.path.join(log_dir, "automation.log"),
        maxBytes=1_000_000, backupCount=3, encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    console = logging.StreamHandler()
    console.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console)
    return logger
