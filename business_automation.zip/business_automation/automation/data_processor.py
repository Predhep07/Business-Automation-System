"""Data processing: read, validate, clean and aggregate sales CSV files.

Expected columns: date, product, region, quantity, unit_price
"""
import csv
import glob
import logging
import os
import shutil
from collections import defaultdict
from datetime import datetime

log = logging.getLogger("automation")

REQUIRED = ["date", "product", "region", "quantity", "unit_price"]
DATE_FORMATS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%d %b %Y")


def parse_date(text: str) -> datetime:
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(text.strip(), fmt)
        except ValueError:
            continue
    raise ValueError(f"unrecognised date '{text}'")


def clean_row(row: dict) -> dict:
    """Validate and normalise one row. Raises ValueError if the row is bad."""
    product = (row.get("product") or "").strip().title()
    region = (row.get("region") or "").strip().title()
    if not product or not region:
        raise ValueError("missing product or region")
    quantity = int(float(row["quantity"]))
    price = float(row["unit_price"])
    if quantity <= 0 or price < 0:
        raise ValueError("quantity must be > 0 and price >= 0")
    date = parse_date(row["date"])
    return {
        "date": date.strftime("%Y-%m-%d"),
        "month": date.strftime("%Y-%m"),
        "product": product,
        "region": region,
        "quantity": quantity,
        "unit_price": round(price, 2),
        "revenue": round(quantity * price, 2),
    }


def process_csv_files(src_dir, clean_dir, reject_dir, archive_dir, failed_dir) -> dict:
    """Process every CSV in src_dir. Returns stats plus the cleaned records."""
    for d in (src_dir, clean_dir, reject_dir, archive_dir, failed_dir):
        os.makedirs(d, exist_ok=True)

    records, rejects = [], []
    files_ok = files_failed = 0

    for path in sorted(glob.glob(os.path.join(src_dir, "*.csv"))):
        name = os.path.basename(path)
        file_records, file_rejects = [], []
        try:
            with open(path, newline="", encoding="utf-8-sig") as fh:
                reader = csv.DictReader(fh)
                headers = [h.strip().lower() for h in (reader.fieldnames or [])]
                missing = [c for c in REQUIRED if c not in headers]
                if missing:
                    raise ValueError(f"missing columns: {', '.join(missing)}")
                for line_no, raw in enumerate(reader, start=2):
                    row = {k.strip().lower(): v for k, v in raw.items() if k}
                    try:
                        file_records.append(clean_row(row))
                    except (ValueError, KeyError, TypeError) as exc:
                        file_rejects.append({"file": name, "line": line_no,
                                             "reason": str(exc), **row})
            records.extend(file_records)
            rejects.extend(file_rejects)
            shutil.move(path, os.path.join(archive_dir, name))
            files_ok += 1
            log.info("Processed %s (%d ok, %d rejected)", name,
                     len(file_records), len(file_rejects))
        except (OSError, ValueError, csv.Error) as exc:
            files_failed += 1
            log.error("Failed to process %s: %s", name, exc)
            shutil.move(path, os.path.join(failed_dir, name))

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if records:
        _write_csv(os.path.join(clean_dir, f"clean_sales_{stamp}.csv"), records)
    if rejects:
        _write_csv(os.path.join(reject_dir, f"rejected_rows_{stamp}.csv"), rejects)
        log.warning("%d invalid row(s) written to rejected_rows_%s.csv", len(rejects), stamp)

    stats = summarize(records)
    stats.update({"files_ok": files_ok, "files_failed": files_failed,
                  "rows_rejected": len(rejects)})
    return stats


def _write_csv(path: str, rows: list) -> None:
    fields = list(dict.fromkeys(k for r in rows for k in r))
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def summarize(records: list) -> dict:
    """Aggregate revenue and units by product, region and month."""
    by_product, by_region, by_month = (defaultdict(float) for _ in range(3))
    units = 0
    for r in records:
        by_product[r["product"]] += r["revenue"]
        by_region[r["region"]] += r["revenue"]
        by_month[r["month"]] += r["revenue"]
        units += r["quantity"]
    total = round(sum(by_product.values()), 2)

    def ranked(d):
        return dict(sorted(((k, round(v, 2)) for k, v in d.items()),
                           key=lambda kv: kv[1], reverse=True))

    return {
        "rows_clean": len(records),
        "total_revenue": total,
        "total_units": units,
        "avg_order_value": round(total / len(records), 2) if records else 0.0,
        "by_product": ranked(by_product),
        "by_region": ranked(by_region),
        "by_month": dict(sorted((k, round(v, 2)) for k, v in by_month.items())),
    }
