@echo off
REM Builds a standalone Windows application (no Python needed to run it).
pip install pyinstaller
pyinstaller --noconfirm --onefile --windowed --name BusinessAutomation gui_app.py
copy config.json dist\config.json
echo.
echo Done! Your app is dist\BusinessAutomation.exe
pause
