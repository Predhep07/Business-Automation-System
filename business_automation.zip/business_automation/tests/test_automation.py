import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from automation.data_processor import clean_row, summarize
from automation.file_organizer import categorize, organize_files


class CleanRowTests(unittest.TestCase):
    def test_valid_row(self):
        r = clean_row({"date": "05/02/2026", "product": " mouse ", "region": "north",
                       "quantity": "2", "unit_price": "650"})
        self.assertEqual(r["product"], "Mouse")
        self.assertEqual(r["revenue"], 1300.0)
        self.assertEqual(r["month"], "2026-02")

    def test_invalid_rows(self):
        base = {"date": "2026-01-01", "product": "a", "region": "b",
                "quantity": "1", "unit_price": "1"}
        for bad in ({"date": "xx"}, {"quantity": "-1"}, {"region": ""}):
            with self.assertRaises(ValueError):
                clean_row({**base, **bad})


class OrganizerTests(unittest.TestCase):
    def test_categories(self):
        self.assertEqual(categorize("a.CSV"), "spreadsheets")
        self.assertEqual(categorize("a.unknown"), "others")

    def test_duplicates_not_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            inbox, out = os.path.join(tmp, "in"), os.path.join(tmp, "out")
            os.makedirs(inbox)
            for _ in range(2):
                open(os.path.join(inbox, "a.txt"), "w").close()
                organize_files(inbox, out)
            self.assertEqual(sorted(os.listdir(os.path.join(out, "documents"))),
                             ["a.txt", "a_1.txt"])


class SummaryTests(unittest.TestCase):
    def test_summary_empty(self):
        self.assertEqual(summarize([])["total_revenue"], 0)


if __name__ == "__main__":
    unittest.main()
