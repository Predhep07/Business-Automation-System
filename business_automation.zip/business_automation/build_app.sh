#!/bin/sh
# Builds a standalone app for Linux/macOS.
pip install pyinstaller
pyinstaller --noconfirm --onefile --windowed --name BusinessAutomation gui_app.py
cp config.json dist/config.json
echo "Done! Your app is in dist/"
