"""The automation pipeline: organize files -> process data -> build report."""
import logging
import os

from .data_processor import process_csv_files, summarize
from .file_organizer import organize_files
from .report_generator import generate_report

log = logging.getLogger("automation")


def run_pipeline(cfg: dict) -> dict:
    """Run all steps once. Each step is isolated so one failure is logged, not fatal."""
    ws = cfg["workspace"]

    def p(*parts):
        return os.path.join(ws, *parts)

    result = {"ok": True, "reports": []}
    log.info("=== Pipeline started ===")

    org = {"moved": 0, "failed": 0, "by_category": {}}
    try:
        org = organize_files(p("inbox"), p("organized"))
        log.info("Organized %d file(s), %d failed", org["moved"], org["failed"])
    except Exception:
        result["ok"] = False
        log.exception("File organization step crashed")

    stats = {**summarize([]), "files_ok": 0, "files_failed": 0, "rows_rejected": 0}
    try:
        stats = process_csv_files(p("organized", "spreadsheets"), p("processed"),
                                  p("rejected"), p("archive"), p("failed"))
        log.info("Processed %d clean row(s), revenue %.2f",
                 stats["rows_clean"], stats["total_revenue"])
    except Exception:
        result["ok"] = False
        log.exception("Data processing step crashed")

    try:
        result["reports"] = generate_report(stats, org, p("reports"), cfg.get("currency", "₹"))
    except Exception:
        result["ok"] = False
        log.exception("Report generation crashed")

    result.update(organize=org, stats=stats)
    log.info("=== Pipeline finished (%s) ===", "success" if result["ok"] else "with errors")
    return result
