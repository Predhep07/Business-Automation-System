"""Business Operations Automation System - desktop application (Tkinter).

Run:  python gui_app.py
Wraps the same engine used by main.py in a window: load/add files, run the
pipeline, auto-run on a schedule, view results, live log, open reports.
"""
import json
import logging
import os
import queue
import shutil
import subprocess
import sys
import threading
import tkinter as tk
import webbrowser
from datetime import datetime
from tkinter import filedialog, messagebox, scrolledtext, ttk

from automation.logger_setup import setup_logging
from automation.pipeline import run_pipeline
from automation.sample_data import create_sample_inbox

# Folder next to the script (or next to the .exe when packaged)
BASE = os.path.dirname(sys.executable if getattr(sys, "frozen", False)
                       else os.path.abspath(__file__))
NAVY, LIGHT = "#12306b", "#eef3fc"


def load_config() -> dict:
    cfg = {"workspace": os.path.join(BASE, "workspace"), "currency": "₹",
           "log_level": "INFO", "schedule_interval_seconds": 60}
    try:
        with open(os.path.join(BASE, "config.json"), encoding="utf-8") as fh:
            cfg.update(json.load(fh))
    except (OSError, json.JSONDecodeError):
        pass
    if not os.path.isabs(cfg["workspace"]):
        cfg["workspace"] = os.path.join(BASE, cfg["workspace"])
    return cfg


class QueueLogHandler(logging.Handler):
    """Sends log records to the GUI thread safely through a queue."""

    def __init__(self, q):
        super().__init__()
        self.q = q

    def emit(self, record):
        self.q.put(("log", self.format(record), record.levelname))


def open_path(path: str) -> None:
    """Open a file/folder with the operating system's default program."""
    if sys.platform.startswith("win"):
        os.startfile(path)  # noqa
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.cfg = load_config()
        self.q = queue.Queue()
        self.run_lock = threading.Lock()
        self.stop_event = threading.Event()
        self.auto_thread = None
        self.last_report = None

        root.title("Business Operations Automation System")
        root.geometry("980x720")
        root.minsize(860, 620)
        self._style()
        self._build_ui()

        setup_logging(os.path.join(self.cfg["workspace"], "logs"), self.cfg["log_level"])
        handler = QueueLogHandler(self.q)
        handler.setFormatter(logging.Formatter("%(asctime)s  %(levelname)-7s %(message)s",
                                               "%H:%M:%S"))
        logging.getLogger("automation").addHandler(handler)

        root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.poll_queue()
        logging.getLogger("automation").info("Application ready. Workspace: %s",
                                             self.cfg["workspace"])

    # ---------------------------------------------------------------- UI
    def _style(self):
        s = ttk.Style()
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure("Card.TFrame", background=LIGHT)
        s.configure("CardTitle.TLabel", background=LIGHT, foreground="#556", font=("Segoe UI", 9))
        s.configure("CardValue.TLabel", background=LIGHT, foreground=NAVY,
                    font=("Segoe UI", 16, "bold"))
        s.configure("Primary.TButton", font=("Segoe UI", 10, "bold"), padding=6)
        s.configure("TButton", padding=5)
        s.configure("Treeview", rowheight=24)
        s.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))

    def _build_ui(self):
        header = tk.Frame(self.root, bg=NAVY)
        header.pack(fill="x")
        tk.Label(header, text="Business Operations Automation System", bg=NAVY, fg="white",
                 font=("Segoe UI", 16, "bold")).pack(anchor="w", padx=16, pady=(10, 0))
        tk.Label(header, text="File organizing  •  Data cleaning  •  Reports  •  Scheduling",
                 bg=NAVY, fg="#b9c8ea", font=("Segoe UI", 9)).pack(anchor="w", padx=16, pady=(0, 10))

        body = ttk.Frame(self.root, padding=12)
        body.pack(fill="both", expand=True)

        # Workspace row
        row = ttk.Frame(body)
        row.pack(fill="x")
        ttk.Label(row, text="Workspace:").pack(side="left")
        self.ws_var = tk.StringVar(value=self.cfg["workspace"])
        self.ws_path = self.cfg["workspace"]  # plain copy: safe to read from worker threads
        self.ws_var.trace_add("write", lambda *_: setattr(
            self, "ws_path", self.ws_var.get().strip() or self.cfg["workspace"]))
        ttk.Entry(row, textvariable=self.ws_var).pack(side="left", fill="x", expand=True, padx=6)
        ttk.Button(row, text="Browse…", command=self.choose_workspace).pack(side="left")

        # Action buttons
        bar = ttk.Frame(body)
        bar.pack(fill="x", pady=10)
        ttk.Button(bar, text="Load Sample Data", command=self.load_sample).pack(side="left")
        ttk.Button(bar, text="Add Files…", command=self.add_files).pack(side="left", padx=6)
        self.run_btn = ttk.Button(bar, text="▶  Run Now", style="Primary.TButton",
                                  command=self.run_now)
        self.run_btn.pack(side="left", padx=6)
        ttk.Button(bar, text="Open Report", command=self.open_report).pack(side="left")
        ttk.Button(bar, text="Open Workspace", command=self.open_workspace).pack(side="left", padx=6)

        # Scheduler row
        sched = ttk.LabelFrame(body, text="Auto-run (scheduler)", padding=8)
        sched.pack(fill="x")
        ttk.Label(sched, text="Run every").pack(side="left")
        self.interval_var = tk.IntVar(value=int(self.cfg["schedule_interval_seconds"]))
        ttk.Spinbox(sched, from_=5, to=86400, width=7, textvariable=self.interval_var
                    ).pack(side="left", padx=6)
        ttk.Label(sched, text="seconds").pack(side="left")
        self.auto_btn = ttk.Button(sched, text="Start Auto-run", command=self.toggle_auto)
        self.auto_btn.pack(side="left", padx=12)
        self.auto_lbl = ttk.Label(sched, text="Stopped", foreground="#a33")
        self.auto_lbl.pack(side="left")

        # Summary cards
        cards = ttk.Frame(body)
        cards.pack(fill="x", pady=10)
        self.card_vars = {}
        for i, title in enumerate(["Total revenue", "Units sold", "Valid rows",
                                   "Rejected rows", "Files moved", "Files failed"]):
            f = ttk.Frame(cards, style="Card.TFrame", padding=8)
            f.grid(row=0, column=i, sticky="nsew", padx=3)
            cards.columnconfigure(i, weight=1)
            var = tk.StringVar(value="–")
            ttk.Label(f, text=title, style="CardTitle.TLabel").pack(anchor="w")
            ttk.Label(f, textvariable=var, style="CardValue.TLabel").pack(anchor="w")
            self.card_vars[title] = var

        # Middle: result tables (left) + log (right)
        mid = ttk.PanedWindow(body, orient="horizontal")
        mid.pack(fill="both", expand=True)

        self.nb = ttk.Notebook(mid)
        self.trees = {}
        for key, label in (("by_product", "By product"), ("by_region", "By region"),
                           ("by_month", "By month")):
            tab = ttk.Frame(self.nb)
            tree = ttk.Treeview(tab, columns=("name", "rev"), show="headings", height=8)
            tree.heading("name", text=label.replace("By ", "").title())
            tree.heading("rev", text="Revenue")
            tree.column("name", width=140)
            tree.column("rev", width=120, anchor="e")
            tree.pack(fill="both", expand=True)
            self.nb.add(tab, text=label)
            self.trees[key] = tree
        mid.add(self.nb, weight=1)

        logf = ttk.Frame(mid)
        ttk.Label(logf, text="Live log").pack(anchor="w")
        self.log_box = scrolledtext.ScrolledText(logf, height=12, state="disabled",
                                                 font=("Consolas", 9), bg="#101828", fg="#d6deeb")
        self.log_box.pack(fill="both", expand=True)
        self.log_box.tag_config("ERROR", foreground="#ff6b6b")
        self.log_box.tag_config("WARNING", foreground="#ffc857")
        self.log_box.tag_config("INFO", foreground="#d6deeb")
        mid.add(logf, weight=2)

        self.status = tk.StringVar(value="Ready")
        ttk.Label(self.root, textvariable=self.status, relief="sunken", anchor="w",
                  padding=(8, 3)).pack(fill="x", side="bottom")

    # ---------------------------------------------------------- actions
    def current_cfg(self) -> dict:
        cfg = dict(self.cfg)
        cfg["workspace"] = self.ws_path
        return cfg

    def inbox(self) -> str:
        return os.path.join(self.current_cfg()["workspace"], "inbox")

    def choose_workspace(self):
        folder = filedialog.askdirectory(title="Choose workspace folder")
        if folder:
            self.ws_var.set(folder)

    def load_sample(self):
        create_sample_inbox(self.inbox())
        logging.getLogger("automation").info("Sample files created in inbox")
        self.status.set("Sample data loaded - click Run Now")

    def add_files(self):
        files = filedialog.askopenfilenames(title="Select files to process")
        if not files:
            return
        os.makedirs(self.inbox(), exist_ok=True)
        for f in files:
            try:
                shutil.copy2(f, self.inbox())
                logging.getLogger("automation").info("Added %s", os.path.basename(f))
            except OSError as exc:
                logging.getLogger("automation").error("Could not add %s: %s", f, exc)
        self.status.set(f"{len(files)} file(s) added to inbox")

    def run_now(self):
        threading.Thread(target=self._worker, daemon=True).start()

    def _worker(self):
        """Runs the pipeline off the UI thread; skips if a run is already active."""
        if not self.run_lock.acquire(blocking=False):
            return
        self.q.put(("busy", True))
        try:
            result = run_pipeline(self.current_cfg())
            self.q.put(("done", result))
        except Exception as exc:  # last-resort safety net
            logging.getLogger("automation").exception("Run failed")
            self.q.put(("error", str(exc)))
        finally:
            self.run_lock.release()
            self.q.put(("busy", False))

    def toggle_auto(self):
        if self.auto_thread and self.auto_thread.is_alive():
            self.stop_event.set()
            self.auto_btn.config(text="Start Auto-run")
            self.auto_lbl.config(text="Stopped", foreground="#a33")
            logging.getLogger("automation").info("Auto-run stopped")
            return
        try:
            interval = max(5, int(self.interval_var.get()))
        except (tk.TclError, ValueError):
            messagebox.showerror("Invalid interval", "Enter the interval in whole seconds.")
            return
        self.stop_event = threading.Event()
        stop = self.stop_event

        def loop():
            while not stop.is_set():
                self._worker()
                stop.wait(interval)

        self.auto_thread = threading.Thread(target=loop, daemon=True)
        self.auto_thread.start()
        self.auto_btn.config(text="Stop Auto-run")
        self.auto_lbl.config(text=f"Running every {interval}s", foreground="#1a7f37")
        logging.getLogger("automation").info("Auto-run started: every %ss", interval)

    def open_report(self):
        if self.last_report and os.path.exists(self.last_report):
            webbrowser.open("file:///" + os.path.abspath(self.last_report).replace("\\", "/"))
        else:
            messagebox.showinfo("No report yet", "Run the automation first to create a report.")

    def open_workspace(self):
        ws = self.current_cfg()["workspace"]
        os.makedirs(ws, exist_ok=True)
        open_path(ws)

    # ------------------------------------------------- queue -> UI updates
    def poll_queue(self):
        try:
            while True:
                kind, *data = self.q.get_nowait()
                if kind == "log":
                    self._append_log(*data)
                elif kind == "busy":
                    self.run_btn.config(state="disabled" if data[0] else "normal")
                    if data[0]:
                        self.status.set("Running…")
                elif kind == "done":
                    self._show_result(data[0])
                elif kind == "error":
                    self.status.set("Error - see log")
                    messagebox.showerror("Run failed", data[0])
        except queue.Empty:
            pass
        self.root.after(150, self.poll_queue)

    def _append_log(self, text, level):
        self.log_box.config(state="normal")
        self.log_box.insert("end", text + "\n", level)
        self.log_box.see("end")
        self.log_box.config(state="disabled")

    def _show_result(self, result: dict):
        st, org, cur = result["stats"], result["organize"], self.cfg["currency"]
        self.card_vars["Total revenue"].set(f"{cur}{st['total_revenue']:,.0f}")
        self.card_vars["Units sold"].set(f"{st['total_units']:,}")
        self.card_vars["Valid rows"].set(st["rows_clean"])
        self.card_vars["Rejected rows"].set(st["rows_rejected"])
        self.card_vars["Files moved"].set(org["moved"])
        self.card_vars["Files failed"].set(st["files_failed"] + org["failed"])
        for key, tree in self.trees.items():
            tree.delete(*tree.get_children())
            for name, rev in st[key].items():
                tree.insert("", "end", values=(name, f"{cur}{rev:,.2f}"))
        html_reports = [r for r in result["reports"] if r.endswith(".html")]
        if html_reports:
            self.last_report = html_reports[0]
        self.status.set(f"Last run {datetime.now():%H:%M:%S} - "
                        f"{'success' if result['ok'] else 'finished with errors'}")

    def on_close(self):
        self.stop_event.set()
        self.root.destroy()


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
