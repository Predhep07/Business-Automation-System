"""Create demo files in the inbox so the system can be tried immediately."""
import csv
import os
import random

PRODUCTS = {"laptop": 55000, "mouse": 650, "keyboard": 1500, "monitor": 12000, "headset": 2500}
REGIONS = ["north", "south", "east", "west"]


def create_sample_inbox(inbox_dir: str, seed: int = 42) -> None:
    rnd = random.Random(seed)
    os.makedirs(inbox_dir, exist_ok=True)
    for month, label in ((1, "jan"), (2, "feb")):
        with open(os.path.join(inbox_dir, f"sales_{label}.csv"), "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["date", "product", "region", "quantity", "unit_price"])
            for _ in range(40):
                prod = rnd.choice(list(PRODUCTS))
                day = rnd.randint(1, 28)
                fmt = rnd.choice(["2026-{m:02d}-{d:02d}", "{d:02d}/{m:02d}/2026"])
                w.writerow([fmt.format(m=month, d=day), f"  {prod} ", rnd.choice(REGIONS),
                            rnd.randint(1, 9), PRODUCTS[prod]])
            # deliberately bad rows to demonstrate validation
            w.writerow(["not-a-date", "mouse", "north", 2, 650])
            w.writerow([f"2026-{month:02d}-10", "laptop", "", 1, 55000])
            w.writerow([f"2026-{month:02d}-11", "monitor", "east", -3, 12000])
    with open(os.path.join(inbox_dir, "broken.csv"), "w") as fh:
        fh.write("foo,bar\n1,2\n")  # wrong columns -> goes to failed/
    for name, data in (("invoice_001.pdf", b"%PDF-1.4"), ("logo.png", b"\x89PNG"),
                       ("meeting_notes.txt", b"Q1 review"), ("backup.zip", b"PK"),
                       ("tool.py", b"print('hi')"), ("mystery.xyz", b"?")):
        with open(os.path.join(inbox_dir, name), "wb") as fh:
            fh.write(data)
