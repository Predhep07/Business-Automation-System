# Industry-Oriented Python Automation System for Business Operations

Automates repetitive business tasks: **file sorting, CSV data cleaning, report generation**,
with error handling, logging and scheduling. Uses only the Python standard library.

## Desktop application (recommended)
```bash
python gui_app.py
```
Click **Load Sample Data** (or **Add Files…**) → **Run Now**. Use **Auto-run** to repeat on a schedule,
**Open Report** to view the HTML report, and watch the live log. Needs Python 3.9+ with Tkinter
(included with the Windows/macOS installers from python.org; on Ubuntu: `sudo apt install python3-tk`).

### Make a standalone app (.exe)
Windows: double-click `build_exe.bat` -> `dist\BusinessAutomation.exe` (no Python needed to run it).
Linux/macOS: `./build_app.sh`. Keep `config.json` next to the app.

## Command-line mode
```bash
python main.py demo                       # create sample data and run once
python main.py run                        # batch run on files in workspace/inbox
python main.py schedule --interval 60     # repeat every 60 seconds
python main.py schedule --interval 5 --max-runs 3
python -m unittest discover tests         # run tests
```

## How it works
| Step | Module | What it does |
|---|---|---|
| 1. File handling | `file_organizer.py` | Moves `workspace/inbox/*` into `organized/<category>/`, never overwrites duplicates |
| 2. Data processing | `data_processor.py` | Validates/cleans sales CSVs (mixed date formats, bad rows), aggregates by product/region/month |
| 3. Reporting | `report_generator.py` | Creates HTML + TXT reports in `workspace/reports/` |
| 4. Orchestration | `pipeline.py` | Runs steps in order, each isolated so one failure doesn't stop the rest |
| 5. Scheduling | `scheduler.py` | Repeats the pipeline at a fixed interval |
| 6. Logging | `logger_setup.py` | Console + rotating `workspace/logs/automation.log` |

## Workspace folders
`inbox` (drop files here) → `organized` → `processed` (cleaned CSV) · `archive` (original CSVs) ·
`rejected` (invalid rows with reasons) · `failed` (unreadable files) · `reports` · `logs`

## CSV format
`date, product, region, quantity, unit_price` (dates: `YYYY-MM-DD`, `DD/MM/YYYY`, `DD-MM-YYYY`, `DD Mon YYYY`)

## Cron / Task Scheduler alternative
Linux/macOS: `0 9 * * 1-5 cd /path/to/project && python main.py run`
Windows: Task Scheduler → action `python main.py run`.

## Extend it
Add a new file category in `CATEGORIES`, a new column rule in `clean_row`, or a new step in `pipeline.py`.
