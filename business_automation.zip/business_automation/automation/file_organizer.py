"""File handling: sort files from an inbox folder into category folders."""
import logging
import os
import shutil
from collections import Counter

log = logging.getLogger("automation")

CATEGORIES = {
    "spreadsheets": {".csv"},
    "documents": {".pdf", ".doc", ".docx", ".txt", ".md"},
    "images": {".png", ".jpg", ".jpeg", ".gif"},
    "archives": {".zip", ".tar", ".gz"},
    "code": {".py", ".js", ".json"},
}


def categorize(filename: str) -> str:
    """Return the category folder name for a file based on its extension."""
    ext = os.path.splitext(filename)[1].lower()
    for category, extensions in CATEGORIES.items():
        if ext in extensions:
            return category
    return "others"


def unique_path(path: str) -> str:
    """Avoid overwriting: report.pdf -> report_1.pdf -> report_2.pdf ..."""
    base, ext = os.path.splitext(path)
    counter = 1
    while os.path.exists(path):
        path = f"{base}_{counter}{ext}"
        counter += 1
    return path


def organize_files(inbox_dir: str, organized_dir: str) -> dict:
    """Move every file in inbox_dir into organized_dir/<category>/.

    Returns a summary: {"moved": int, "failed": int, "by_category": {...}}.
    One bad file never stops the batch.
    """
    os.makedirs(inbox_dir, exist_ok=True)
    counts, failed = Counter(), 0
    for name in sorted(os.listdir(inbox_dir)):
        src = os.path.join(inbox_dir, name)
        if not os.path.isfile(src):
            continue
        try:
            category = categorize(name)
            dest_dir = os.path.join(organized_dir, category)
            os.makedirs(dest_dir, exist_ok=True)
            dest = unique_path(os.path.join(dest_dir, name))
            shutil.move(src, dest)
            counts[category] += 1
            log.info("Moved %s -> %s/", name, category)
        except (OSError, shutil.Error) as exc:
            failed += 1
            log.error("Could not move %s: %s", name, exc)
    return {"moved": sum(counts.values()), "failed": failed, "by_category": dict(counts)}
