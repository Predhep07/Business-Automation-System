"""Output report generation (HTML + plain text)."""
import html
import logging
import os
from datetime import datetime

log = logging.getLogger("automation")


def _table(title: str, data: dict, cur: str) -> str:
    rows = "".join(f"<tr><td>{html.escape(str(k))}</td><td class='n'>{cur}{v:,.2f}</td></tr>"
                   for k, v in data.items())
    return f"<h2>{title}</h2><table><tr><th>Name</th><th>Revenue</th></tr>{rows}</table>"


def generate_report(stats: dict, org: dict, report_dir: str, currency: str = "₹") -> list:
    """Write report_<timestamp>.html and .txt. Returns the file paths."""
    os.makedirs(report_dir, exist_ok=True)
    now = datetime.now()
    stamp = now.strftime("%Y%m%d_%H%M%S")
    when = now.strftime("%d %b %Y, %H:%M")

    cards = [
        ("Total revenue", f"{currency}{stats['total_revenue']:,.2f}"),
        ("Units sold", f"{stats['total_units']:,}"),
        ("Avg. order value", f"{currency}{stats['avg_order_value']:,.2f}"),
        ("Valid rows", stats["rows_clean"]),
        ("Rejected rows", stats["rows_rejected"]),
        ("Files moved", org.get("moved", 0)),
    ]
    card_html = "".join(f"<div class='card'><span>{k}</span><b>{v}</b></div>" for k, v in cards)
    page = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>Business Automation Report</title><style>
body{{font-family:Segoe UI,Arial,sans-serif;max-width:900px;margin:30px auto;padding:0 16px;color:#1d2a44}}
h1{{color:#12306b}} .cards{{display:flex;flex-wrap:wrap;gap:12px}}
.card{{flex:1 1 130px;background:#eef3fc;border-radius:8px;padding:12px}}
.card span{{display:block;font-size:12px;color:#556}} .card b{{font-size:20px}}
table{{border-collapse:collapse;width:100%;margin-bottom:12px}}
th,td{{border-bottom:1px solid #d5ddec;padding:6px 10px;text-align:left}} .n{{text-align:right}}
</style></head><body>
<h1>Business Operations Automation Report</h1><p>Generated: {when}</p>
<div class="cards">{card_html}</div>
{_table("Revenue by product", stats["by_product"], currency)}
{_table("Revenue by region", stats["by_region"], currency)}
{_table("Revenue by month", stats["by_month"], currency)}
<p>Files processed OK: {stats['files_ok']} | Files failed: {stats['files_failed']}
| Files by category: {html.escape(str(org.get('by_category', {})))}</p>
</body></html>"""

    lines = [f"BUSINESS AUTOMATION REPORT - {when}", "=" * 50,
             f"Total revenue   : {currency}{stats['total_revenue']:,.2f}",
             f"Units sold      : {stats['total_units']:,}",
             f"Avg order value : {currency}{stats['avg_order_value']:,.2f}",
             f"Valid rows      : {stats['rows_clean']}  Rejected: {stats['rows_rejected']}",
             f"Files OK/failed : {stats['files_ok']}/{stats['files_failed']}", ""]
    for title, key in (("By product", "by_product"), ("By region", "by_region"),
                       ("By month", "by_month")):
        lines.append(title)
        lines += [f"  {k:<20}{currency}{v:>12,.2f}" for k, v in stats[key].items()]
        lines.append("")

    paths = []
    for ext, content in (("html", page), ("txt", "\n".join(lines))):
        path = os.path.join(report_dir, f"report_{stamp}.{ext}")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(content)
        paths.append(path)
        log.info("Report written: %s", path)
    return paths
